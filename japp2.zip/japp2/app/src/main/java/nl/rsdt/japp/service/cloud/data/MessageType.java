package nl.rsdt.japp.service.cloud.data;

/**
 * @author Dingenis Sieger Sinke
 * @version 1.0
 * @since 11-9-2016
 * Description...
 */
public class MessageType {

    public static final String NOTICE = "notice";

    public static final String UPDATE = "update";

    public static final String NEW = "new";

}
