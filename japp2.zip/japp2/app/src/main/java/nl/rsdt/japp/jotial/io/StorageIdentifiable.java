package nl.rsdt.japp.jotial.io;

/**
 * @author Dingenis Sieger Sinke
 * @version 1.0
 * @since 31-7-2016
 * Description...
 */
public interface StorageIdentifiable {

    String getStorageId();

}
