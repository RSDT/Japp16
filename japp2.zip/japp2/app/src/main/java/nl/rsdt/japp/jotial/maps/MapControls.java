package nl.rsdt.japp.jotial.maps;

/**
 * @author Dingenis Sieger Sinke
 * @version 1.0
 * @since 10-10-2016
 * Description...
 */

public class MapControls {

    public static final int ZOOM = 0;

    public static final int COMPASS = 1;

    public static final int LEVEL = 2;

    public static final int TOOLBAR = 3;

}
