package nl.rsdt.japp.jotial.maps.wrapper;

/**
 * Created by mattijn on 09/08/17.
 */

public interface OnMapReadyCallback {
    void onMapReady(IJotiMap jotiMap);
}
