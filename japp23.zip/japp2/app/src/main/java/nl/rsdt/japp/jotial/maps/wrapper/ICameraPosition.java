package nl.rsdt.japp.jotial.maps.wrapper;

import org.osmdroid.views.MapView;

/**
 * Created by mattijn on 17/08/17.
 */

public interface ICameraPosition {
    public float getZoom() ;

    public float getTilt() ;
}
