package nl.rsdt.japp.jotial.maps.wrapper.osm;

import org.osmdroid.views.MapView;

import nl.rsdt.japp.jotial.maps.wrapper.IUiSettings;

/**
 * Created by mattijn on 09/08/17.
 */

public class OsmUiSettings implements IUiSettings{
    private final MapView osmMap;

    public OsmUiSettings(MapView osmMap) {
        this.osmMap = osmMap;
    }

    public void setAllGesturesEnabled(boolean allesturesEnabled) {
        //// TODO: 30/08/17
    }

    public void setCompassEnabled(boolean compassEnabled) {
        //// TODO: 30/08/17
    }

    public void setZoomControlsEnabled(boolean zoomControlsEnabled) {
        //// TODO: 30/08/17
    }

    public void setIndoorLevelPickerEnabled(boolean indoorLevelPickerEnabled) {
       //// TODO: 30/08/17
    }

    public void setMapToolbarEnabled(boolean mapToolbarEnabled) {
        //// TODO: 30/08/17
    }
}
