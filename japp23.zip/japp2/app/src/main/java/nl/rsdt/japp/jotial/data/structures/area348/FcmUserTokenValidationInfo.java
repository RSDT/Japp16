package nl.rsdt.japp.jotial.data.structures.area348;

import com.google.gson.annotations.SerializedName;

/**
 * @author Dingenis Sieger Sinke
 * @version 1.0
 * @since 7-9-2016
 * Description...
 */
public class FcmUserTokenValidationInfo {

    @SerializedName("fcm")
    private boolean isValid;

}
